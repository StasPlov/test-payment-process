-- --------------------------------------------------------
-- Хост:                         192.168.8.85
-- Версия сервера:               10.3.38-MariaDB-0ubuntu0.20.04.1 - Ubuntu 20.04
-- Операционная система:         debian-linux-gnu
-- HeidiSQL Версия:              12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица test_payment_process.country
CREATE TABLE IF NOT EXISTS `country` (
  `code` varchar(2) NOT NULL,
  `name` varchar(1000) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы test_payment_process.country: ~4 rows (приблизительно)
DELETE FROM `country`;
INSERT INTO `country` (`code`, `name`) VALUES
	('DE', 'Германия'),
	('FR', 'Франция'),
	('GR', 'Греция'),
	('IT', 'Италия');

-- Дамп структуры для таблица test_payment_process.country_tax
CREATE TABLE IF NOT EXISTS `country_tax` (
  `country_id` varchar(2) NOT NULL,
  `tax` double NOT NULL,
  PRIMARY KEY (`country_id`),
  CONSTRAINT `FK_B5A98CE7F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы test_payment_process.country_tax: ~3 rows (приблизительно)
DELETE FROM `country_tax`;
INSERT INTO `country_tax` (`country_id`, `tax`) VALUES
	('DE', 19),
	('GR', 24),
	('IT', 22);

-- Дамп структуры для таблица test_payment_process.coupon
CREATE TABLE IF NOT EXISTS `coupon` (
  `code` varchar(255) NOT NULL,
  `type_id` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`code`),
  KEY `IDX_64BF3F02C54C8C93` (`type_id`),
  CONSTRAINT `FK_64BF3F02C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `coupon_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы test_payment_process.coupon: ~2 rows (приблизительно)
DELETE FROM `coupon`;
INSERT INTO `coupon` (`code`, `type_id`, `discount`) VALUES
	('D15', 2, 100),
	('D215', 1, 8);

-- Дамп структуры для таблица test_payment_process.coupon_type
CREATE TABLE IF NOT EXISTS `coupon_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы test_payment_process.coupon_type: ~2 rows (приблизительно)
DELETE FROM `coupon_type`;
INSERT INTO `coupon_type` (`id`, `title`) VALUES
	(1, 'Фиксированная сумма скидки'),
	(2, 'Процент от суммы покупки');

-- Дамп структуры для таблица test_payment_process.doctrine_migration_versions
CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Дамп данных таблицы test_payment_process.doctrine_migration_versions: ~2 rows (приблизительно)
DELETE FROM `doctrine_migration_versions`;
INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
	('DoctrineMigrations\\Version20230606034205', '2023-06-06 03:42:45', 908),
	('DoctrineMigrations\\Version20230606041659', '2023-06-06 04:17:03', 1025);

-- Дамп структуры для таблица test_payment_process.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `name` varchar(255) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `price` double NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  `is_hide` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Дамп данных таблицы test_payment_process.product: ~3 rows (приблизительно)
DELETE FROM `product`;
INSERT INTO `product` (`id`, `created_at`, `update_at`, `name`, `description`, `price`, `is_delete`, `is_hide`) VALUES
	(1, '2023-06-06 03:47:19', '2023-06-06 03:47:19', 'IPhone', NULL, 100, 0, 0),
	(2, '2023-06-06 03:47:37', '2023-06-06 03:47:37', 'Наушники', NULL, 20, 0, 0),
	(3, '2023-06-06 03:47:50', '2023-06-06 03:47:50', 'Чехол', NULL, 10, 0, 0);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
